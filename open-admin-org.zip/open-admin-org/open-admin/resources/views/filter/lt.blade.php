<div class="form-group row">
    <label class="col-sm-2 control-label">{{$label}}&nbsp;(&lt;)</label>
    <div class="col-sm-8">
        @include($presenter->view())
    </div>
</div>