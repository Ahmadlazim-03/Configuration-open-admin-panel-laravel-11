<?php

namespace OpenAdmin\Admin\Form\Field;

class CheckboxCard extends CheckboxButton
{
    /**
     * {@inheritdoc}
     */
    public function render()
    {
        return parent::render();
    }
}
